sudo mount -o remount ,rw /mnt/usbdrive0
